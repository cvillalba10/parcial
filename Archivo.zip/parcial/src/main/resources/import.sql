

INSERT INTO Paises (id,codigo_pais, Pais) VALUES (1,'AU', 'Australia');
INSERT INTO Paises (id,codigo_pais, Pais) VALUES (2,'AU2', 'Brasil');
INSERT INTO Paises (id,codigo_pais, Pais) VALUES (3,'AU3', 'Bolivia');
INSERT INTO Paises (id,codigo_pais, Pais) VALUES (4,'AU3', 'Peru');
INSERT INTO Paises (id,codigo_pais, Pais) VALUES (5,'AU4', 'Panama');

INSERT INTO Ciudades (id, codigo_pais, name) VALUES  (1, 'AU', 'Cape Town');
INSERT INTO Ciudades (id, codigo_pais, name) VALUES  (2, 'AU', 'Cape Town2');
INSERT INTO Ciudades (id, codigo_pais, name) VALUES  (3, 'AU', 'Cape Town3');
INSERT INTO Ciudades (id, codigo_pais, name) VALUES  (4, 'AU2', 'Brasilia');
INSERT INTO Ciudades (id, codigo_pais, name) VALUES  (5, 'AU3', 'Lima');
INSERT INTO Ciudades (id, codigo_pais, name) VALUES  (6, 'AU4', 'Panama');